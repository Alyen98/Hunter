package org.acme;

public class CardCreationRequest {
    public String nenAbility;
    public String exam;
    public NenType nenType;
}
