package org.acme;

import java.time.LocalDate;

public class LicenseCreationRequest {
    public String licenseNumber;
    public LocalDate issueDate;
}
