package org.acme;

public enum NenType {
    Fortificador,
    Emissor,
    Manipulador,
    Conjurador,
    Transmutador,
    Especialista
}